<!DOCTYPE HTML>
<?php echo '<html lang="uk">' ?>
<head>
	<title><?php echo $title; ?></title>
	<meta charset="utf-8">
	<meta name="description" content="<?php echo $system_name; ?>">
	<meta name="theme-color" content="<?php echo $main_color; ?>" />
	<meta name="viewport" content="width=device-width, user-scalable=no">
	<link href="<?php echo $dom; ?>/karat/css/bootstrap-icons.min.css" rel="stylesheet">
	<link href="<?php echo $dom; ?>/karat/css/bootstrap.min.css" rel="stylesheet">
	<link href="<?php echo $dom; ?>/karat/css/e-karat.css?<?php echo time(); ?>" rel="stylesheet"/>
	<style>
		.main-color,.nav-link.active,.active>.page-link, .page-link.active
		{
			background-color: <?php echo $main_color; ?> !important;
			color: white !important;
		}
		.logo,.row .main-color,.form select,.input-group-text,.form-control,.form-select,.ramka_full,.table-karat td,.table-karat th,.all_in_month,.active>.page-link, .page-link.active
		{
			border: 1px solid <?php echo $main_color; ?>;
		}
	</style>
	<script src="<?php echo $dom; ?>/karat/js/bootstrap.bundle.min.js"> </script>
	<script src="<?php echo $dom; ?>/karat/js/jquery.min.js"> </script>
	<script src="<?php echo $dom; ?>/karat/js/jquery.maskedinput.min.js"> </script>
</head>
<?php
include $_SERVER['DOCUMENT_ROOT'] . '/nav_menu.php';
?>
<?php echo '<body id="e_store" class='.$bg_class.'>' ?>
<?php echo '<div class="container my-3 '.$bg_class.'">' ?>
<?php
if (isset($_SESSION['message'])) {
	echo $_SESSION['message'];
	unset($_SESSION['message']);
}
?>