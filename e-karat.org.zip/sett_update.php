<?php
include $_SERVER['DOCUMENT_ROOT'] . '/settdata.php';
$title = 'Налаштування';
//отримати хеш та юзера
if (isset($_COOKIE['id']) and isset($_COOKIE['hash'])) {
	//-------------------------------------------------------------------------//
	// оновити профіль
	//-------------------------------------------------------------------------//
	if (isset($_POST['delete_avatar'])) {
		$id       = $_POST['id'];
		$filename = $_POST['dir_avatar'];
		unlink($filename);
		$query    = $pdo->query("UPDATE `users` SET `user_avatar`='' WHERE `user_id`='$id'");
		header("Refresh:1;url='$dom/karat/menu/e_profile.php?id=$id'");
		include $_SERVER ['DOCUMENT_ROOT'] . '/header.php';
		echo "<div class='alert alert-primary my-3' role='alert'>Оновлюю...</div>";
		echo "<div class='spinner-grow main-color' role='status'><span class='visually-hidden'>Load...</span></div>";
		$_SESSION['message'] = "<div class='alert alert-success my-3' role='alert'>Видалено!</div>";
		exit();
	}
	if (isset($_POST['edit_profile'])) {
		$id       = $_POST['id'];
		$f_name   = $_POST['f_name'];
		$l_name   = $_POST['l_name'];
		$user_login = $_POST['user_login'];
		$user_date   = $_POST['user_date'];
		$up_avatar = isset($_POST['up_avatar']) ? $_POST['up_avatar'] : '0';
		//компресувати фото аватара
		function optimize($image)
		{
			$size = 512;
			$ext = pathinfo($image);
			if (!array_key_exists('extension',$ext)) {
				throw new Exception('Отсутствует разширение файла!');
			}
			if (!array_key_exists('filename',$ext)) {
				throw new Exception('Отсутствует имя файла!');
			}
			$extension = $ext['extension'];
			if ($extension == "") {
				throw new Exception('Отсутствует разширение файла!');
			}
			$im = new Imagick($image);
			$height = $im->getImageHeight();
			$width = $im->getImageWidth();
			if ($height < $size && $width < $size) {
				$im->adaptiveResizeImage($width,$height);
			}
			if ($height > $size && $width > $size && $height == $width) {
				$im->adaptiveResizeImage($size,$size);
			}
			if ($height > $width && $height > $size) {
				$im->adaptiveResizeImage(0,$size);
			}
			if ($width > $height && $width > $size) {
				$im->adaptiveResizeImage($size,0);
			}
			// Optimize the image layers
			$im->optimizeImageLayers();
			// Compression and quality
			$im->setImageCompression(Imagick::COMPRESSION_JPEG);
			$im->setImageCompressionQuality(55);
			// Write the image back
			$im->writeImages($image, true);
		}
		$target_dir = $_SERVER['DOCUMENT_ROOT'] . '/karat/avatars/';
		//перевірити чи файл вибрано
		if (!empty($_FILES['avatar']['tmp_name'][0])) {
			$file_name = $_FILES["avatar"]["name"];
			$ext = end(explode(".", $file_name));
			$new_name = $user_login .".".$ext;
			$target_file = $target_dir . $new_name;
			$uploadOk = 1;
			$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
		}
		// Check if image file is a actual image or fake image
		if (isset($_POST["avatar"])) {
			$check = getimagesize($_FILES["avatar"]["tmp_name"]);
			if ($check !== false) {
				echo "Зображення - " . $check["mime"] . ".";
				$uploadOk = 1;
			} else {
				$img_err1 =  " - файл не є зображенням.";
				$uploadOk = 0;
			}
		}
		//перевірити чи файл вибрано
		if (!empty($_FILES['avatar']['tmp_name'][0])) {
			// Check if file already exists
			if (file_exists($target_file)) {
				$img_err2 = " - файл уже існує.";
				$uploadOk = 0;
			}
			// Check file size
			if ($_FILES["avatar"]["size"] > 5000000) {
				$img_err3 = " - розмір файлу перевищує 5 MB";
				$uploadOk = 0;
			}
			// Allow certain file formats
			if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
			&& $imageFileType != "gif" ) {
				$img_err4 = " - тільки з таким розширенням (JPG, JPEG, PNG або GIF)";
				$uploadOk = 0;
			}
			// Check if $uploadOk is set to 0 by an error
			if ($uploadOk == 0) {
				$img_err5 = " - файл не було завантажено.";
				// if everything is ok, try to upload file
			} else {
				if (move_uploaded_file($_FILES["avatar"]["tmp_name"], $target_file)) {
					//$img_profile = " - аватар ". htmlspecialchars( basename( $_FILES["avatar"]["name"])). " завантажено!";
					$file_name = $_FILES["avatar"]["name"];
					$ext = end(explode(".", $file_name));
					$new_name = $user_login .".".$ext;
					$img_profile = optimize($dir_abs.'karat/avatars/'.$new_name);
					$img_profile = " - аватар завантажено!";
				} else {
					$img_err6 = " - при завантаженні авки виникли помилки.";
				}
			}
		}
		if (isset($_POST["up_avatar"])) {
			$new_name = $up_avatar;
		}

		$query          = $pdo->query("
		UPDATE `users` SET
		`f_name` ='$f_name',
		`l_name` = '$l_name',
		`user_login` = '$user_login',
		`user_date`='$user_date',
		`user_avatar`='$new_name'
		 WHERE `user_id`='$id'");
		header("Refresh:1;url=".$dom."/");
		include $_SERVER ['DOCUMENT_ROOT'] . '/header.php';
		echo "<div class='alert alert-primary my-3' role='alert'>Оновлюю...</div>";
		echo "<div class='spinner-grow main-color' role='status'><span class='visually-hidden'>Load...</span></div>";
		$_SESSION['message'] = "<div class='alert alert-success my-3' role='alert'>Профіль оновлено!</div>";
		exit();
	}
	//Дати доступ вказаним користувачм
	if ($access == "super_admin") {
		// Create zip створити копію файлів в архів
		if (isset($_POST['create'])) {
			$filename    = "backup.zip";
			$filename_db = "backup_db.sql";
			if (file_exists($filename) && file_exists($filename_db)) {
				unlink($filename);
				unlink($filename_db);
			}
			$dir = $dir_abs;
			function createZip($zip, $dir)
			{
				if (is_dir($dir)) {
					if ($dh = opendir($dir)) {
						while (($file = readdir($dh)) !== false) {
							// If file
							if (is_file($dir.$file)) {
								if ($file != '' && $file != '.' && $file != '..') {
									$zip->addFile($dir.$file);
								}
							} else {
								// If directory
								if (is_dir($dir.$file) ) {
									if ($file != '' && $file != '.' && $file != '..') {
										// Add empty directory
										$zip->addEmptyDir($dir.$file);
										$folder = $dir.$file.'/';
										// Read data of the folder
										createZip($zip,$folder);
									}
								}
							}
						}
						closedir($dh);
					}
				}
			}
			// Create ZIP file
			$zip      = new ZipArchive();
			$filename = "./backup.zip";
			if ($zip->open($filename, ZipArchive::CREATE) !== TRUE) {
				exit("cannot open <$filename>\n");
			}
			// Create zip
			createZip($zip,$dir);
			$zip->close();
			// Create db sql
			include $_SERVER['DOCUMENT_ROOT'] . '/backup_sql.php';
			// Reload
			header("Refresh: 3; url=".$dom."/settings.php");
			include $_SERVER ['DOCUMENT_ROOT'] . '/header.php';
			echo "<div class='alert alert-primary my-3' role='alert'>Зажди...</div>";
			echo "<div class='spinner-grow main-color' role='status'><span class='visually-hidden'>Load...</span></div>";
			$_SESSION['message'] = "<div class='alert alert-success my-3' role='alert'>Архів файлів та копію бази даних створено!</div>";
			exit ();
		}
		// Download Created Zip file
		if (isset($_POST['download_source'])) {
			$filename = "backup.zip";
			if (file_exists($filename)) {
				header('Content-Type: application/zip');
				header('Content-Disposition: attachment; filename="Ver_'.$ver.'_'.$backup.'_'.basename($filename).'"');
				header('Content-Length: ' . filesize($filename));
				flush();
				readfile($filename);
				exit;
			} else {
				header("Refresh: 0; url=".$dom."/settings.php");
				$_SESSION['message'] = "<div class='alert alert-primary my-3' role='alert'>Копій немає!</div>";
				exit ();
			}
		}
		// Download Created backup_db
		if (isset($_POST['download_db'])) {
			$filename = "backup_db.sql";
			if (file_exists($filename)) {
				header('Content-Type: application/zip');
				header('Content-Disposition: attachment; filename="'.$backup.'_'.basename($filename).'"');
				header('Content-Length: ' . filesize($filename));
				flush();
				readfile($filename);
				exit;
			} else {
				header("Refresh: 0; url=".$dom."/settings.php");
				$_SESSION['message'] = "<div class='alert alert-primary my-3' role='alert'>Копій немає!</div>";
				exit ();
			}
		}
		// Dell backup
		if (isset($_POST['dell_backup'])) {
			$filename    = "backup.zip";
			$filename_db = "backup_db.sql";
			if (file_exists($filename) && file_exists($filename_db)) {
				unlink($filename);
				unlink($filename_db);
				header("Refresh: 1; url=".$dom."/settings.php");
				include $_SERVER ['DOCUMENT_ROOT'] . '/header.php';
				echo "<div class='alert alert-primary my-3' role='alert'>Зажди...</div>";
				echo "<div class='spinner-grow main-color' role='status'><span class='visually-hidden'>Load...</span></div>";
				$_SESSION['message'] = "<div class='alert alert-success my-3' role='alert'>Копії видалено!</div>";
				exit ();
			} else {
				header("Refresh: 0; url=".$dom."/settings.php");
				$_SESSION['message'] = "<div class='alert alert-primary my-3' role='alert'>Копій немає!</div>";
				exit ();
			}
		}
		//видалити години
		if (isset ( $_POST ['drop_time'] )) {
			$drop = $pdo->query("TRUNCATE TABLE `e_time`");
			header("Refresh: 1; url=".$dom."/settings.php");
			include $_SERVER ['DOCUMENT_ROOT'] . '/header.php';
			echo "<div class='alert alert-primary my-3' role='alert'>Зажди...</div>";
			echo "<div class='spinner-grow main-color' role='status'><span class='visually-hidden'>Load...</span></div>";
			$_SESSION['message'] = "<div class='alert alert-success my-3' role='alert'>Таблицю годин очищено!</div>";
			exit ();
		}
		//видалити товари
		if (isset ( $_POST ['drop_prod'] )) {
			$drop = $pdo->query("TRUNCATE TABLE `e_products`;TRUNCATE TABLE `e_prod_to_cat`;TRUNCATE TABLE `e_prod_to_stor`");
			header("Refresh: 1; url=".$dom."/settings.php");
			include $_SERVER ['DOCUMENT_ROOT'] . '/header.php';
			echo "<div class='alert alert-primary my-3' role='alert'>Зажди...</div>";
			echo "<div class='spinner-grow main-color' role='status'><span class='visually-hidden'>Load...</span></div>";
			$_SESSION['message'] = "<div class='alert alert-success my-3' role='alert'>Таблицю товарів та асоціації очищено!</div>";
			exit ();
		}
		//видалити категорії
		if (isset ( $_POST ['drop_cats'] )) {
			$drop = $pdo->query("TRUNCATE TABLE `e_sub_cat`; TRUNCATE TABLE `e_prod_to_cat`");
			header("Refresh: 1; url=".$dom."/settings.php");
			include $_SERVER ['DOCUMENT_ROOT'] . '/header.php';
			echo "<div class='alert alert-primary my-3' role='alert'>Зажди...</div>";
			echo "<div class='spinner-grow main-color' role='status'><span class='visually-hidden'>Load...</span></div>";
			$_SESSION['message'] = "<div class='alert alert-success my-3' role='alert'>Таблицю категорій та асоціації очищено!</div>";
			exit ();
		}
		//видалити склади
		if (isset ( $_POST ['drop_store'] )) {
			$drop = $pdo->query("TRUNCATE TABLE `e_store`");
			header("Refresh: 1; url=".$dom."/settings.php");
			include $_SERVER ['DOCUMENT_ROOT'] . '/header.php';
			echo "<div class='alert alert-primary my-3' role='alert'>Зажди...</div>";
			echo "<div class='spinner-grow main-color' role='status'><span class='visually-hidden'>Load...</span></div>";
			$_SESSION['message'] = "<div class='alert alert-success my-3' role='alert'>Таблицю складів очищено!</div>";
			exit ();
		}
		//видалити товари з комірок
		if (isset ( $_POST ['drop_assoc_prod_st'] )) {
			$drop = $pdo->query("TRUNCATE TABLE `e_prod_to_stor`");
			header("Refresh: 1; url=".$dom."/settings.php");
			include $_SERVER ['DOCUMENT_ROOT'] . '/header.php';
			echo "<div class='alert alert-primary my-3' role='alert'>Зажди...</div>";
			echo "<div class='spinner-grow main-color' role='status'><span class='visually-hidden'>Load...</span></div>";
			$_SESSION['message'] = "<div class='alert alert-success my-3' role='alert'>Таблицю комірок очищено!</div>";
			exit ();
		}
		//записати налаштування
		if (isset ( $_POST ['sett'] )) {
			$system_name = $_POST ['system_name'];
			$system_logo = $_POST ['system_logo'];
			$limit_watch = $_POST ['limit_watch'];
			$stavka_grn  = $_POST ['stavka_grn'];
			$stock_default  = $_POST ['stock_default'];
			$main_color  = $_POST ['main_color'];
			$bg_color    = isset($_POST['bg_color']) ? $_POST['bg_color'] : '0';
			$time_pm     = $_POST ['time_pm'];
			$time_am     = $_POST ['time_am'];
			$gads       = isset($_POST['gads']) ? $_POST['gads'] : '0';
			$text_gads  = $_POST ['text_gads'];
			$ver  = $_POST ['ver'];
			try {
				$data = array (
				'system_name'=> $system_name,
				'system_logo'=> $system_logo,
				'limit_watch'=> $limit_watch,
				'stavka_grn' => $stavka_grn,
				'stock_default' => $stock_default,
				'main_color' => $main_color,
				'bg_color'   => $bg_color,
				'time_pm'    => $time_pm,
				'time_am'    => $time_am,
				'gads'       => $gads,
				'text_gads'  => $text_gads,
				'ver'        => $ver
				);
				// Підготовити запис але спочатку перевірити таблицю на присутність запису
				$query = $pdo->query ( "SELECT id FROM `settings` LIMIT 1" );
				if (! $query->fetch ()) {
					$query = $pdo->prepare ( "
						INSERT INTO settings
						(
						system_name,
						system_logo,
						limit_watch,
						stavka_grn,
						stock_default,
						main_color,
						bg_color,
						time_pm,
						time_am,
						gads,
						text_gads,
						ver
						)
						values
						(
						:system_name,
						:system_logo,
						:limit_watch,
						:stavka_grn,
						:stock_default,
						:main_color,
						:bg_color,
						:time_pm,
						:time_am,
						:gads,
						:text_gads,
						:ver
						)" );
				} else {
					$query = $pdo->prepare ( "
						UPDATE settings SET
						system_name=:system_name,
						system_logo=:system_logo,
						limit_watch=:limit_watch,
						stavka_grn=:stavka_grn,
						stock_default=:stock_default,
						main_color=:main_color,
						bg_color=:bg_color,
						time_pm=:time_pm,
						time_am=:time_am,
						gads=:gads,
						text_gads=:text_gads,
						ver=:ver
						" );
				}
				$query->execute ( $data );
				$result = true;
			} catch ( PDOException $e ) {
				echo "<div class='alert alert-danger my-3'>Помилка!: " . $e->getMessage () . "</div>";
			}
			if ($result) {
				header("Refresh: 1; url=".$dom."/settings.php");
				include $_SERVER ['DOCUMENT_ROOT'] . '/header.php';
				echo "<div class='alert alert-primary my-3' role='alert'>Зажди...</div>";
				echo "<div class='spinner-grow main-color' role='status'><span class='visually-hidden'>Load...</span></div>";
				$_SESSION['message'] = "<div class='alert alert-success my-3' role='alert'>Налаштування оновлено!</div>";
				exit ();
			}
		}
		if (isset ( $_POST ['sett_user'] )) {
			$user   = $_POST ['user'];
			$access = $_POST ['access'];
			try {
				$data = array (
				'access'=> $access
				);
				// Підготовити запис але спочатку перевірити таблицю на присутність запису
				$query = $pdo->prepare ( "UPDATE users SET access=:access WHERE user_login='$user'" );
				// Запит з даними
				$query->execute ($data);
				// Записати в змінну
				$result= true;
			} catch (PDOException $e) {
				// На випадок помилки вивести
				echo "<div class='alert alert-danger my-3'>Помилка!: " . $e->getMessage () . "</div>";
			}
			if ($result) {
				header("Refresh: 1; url=".$dom."/settings.php");
				include $_SERVER ['DOCUMENT_ROOT'] . '/header.php';
				echo "<div class='alert alert-primary my-3' role='alert'>Зажди...</div>";
				echo "<div class='spinner-grow main-color' role='status'><span class='visually-hidden'>Load...</span></div>";
				$_SESSION['message'] = "<div class='alert alert-success my-3' role='alert'>Права змінено!</div>";
				exit ();
			}
		}
		// створити меню
		if (isset ($_POST ['add_menu'])) {
			$menu_name  = $_POST ['menu_name'];
			$menu_alias = $_POST ['menu_alias'];
			$menu_file  = $_POST ['menu_file'];
			$menu_icon  = $_POST ['menu_icon'];
			try {
				$data = array (
				'menu_name'  => $menu_name,
				'menu_alias' => $menu_alias,
				'menu_file'  => $menu_file,
				'menu_icon'  => $menu_icon
				);
				$query = $pdo->prepare ( "
						INSERT INTO e_menu
						(
						menu_name,
						menu_alias,
						menu_file,
						menu_icon
						)
						values
						(
						:menu_name,
						:menu_alias,
						:menu_file,
						:menu_icon
						)" );
				// Запит з даними
				$query->execute ($data);
				// Записати в змінну
				$result= true;
			} catch (PDOException $e) {
				// На випадок помилки вивести
				echo "<div class='alert alert-danger my-3'>Помилка!: " . $e->getMessage () . "</div>";
			}
			if ($result) {
				header("Refresh: 1; url=".$dom."/settings.php");
				include $_SERVER ['DOCUMENT_ROOT'] . '/header.php';
				echo "<div class='alert alert-primary my-3' role='alert'>Зажди...</div>";
				echo "<div class='spinner-grow main-color' role='status'><span class='visually-hidden'>Load...</span></div>";
				$_SESSION['message'] = "<div class='alert alert-success my-3' role='alert'>Меню додано!</div>";
				exit ();
			}
		}
		//створити нового юзера
		if (isset ( $_POST ['add_new_user'] )) {
			$err = [ ];
			// перевіримо логін
			if (! preg_match ( "/^[a-zA-Z0-9]+$/", $_POST ['login'] )) {
				$err [] = "логін (тільки латинські)";
			}
			if (strlen ( $_POST ['login'] ) < 3 or strlen ( $_POST ['login'] ) > 30) {
				$err [] = "логін (від 3-х до 30 символів)";
			}
			if (strlen ( $_POST ['password'] ) < 4 or strlen ( $_POST ['password'] ) > 8) {
				$err [] = "пароль (від 4-х до 8 символів)";
			}
			// перевірка, чи нема користувача з таким іменем
			$user      = $_POST ['login'];
			$result    = $pdo->query ( "SELECT SQL_CALC_FOUND_ROWS user_id FROM users WHERE user_login='$user' LIMIT 1" );
			$result->execute ();
			$result    = $pdo->prepare ( "SELECT FOUND_ROWS()" );
			$result->execute ();
			$row_count = $result->fetchColumn ();
			if ($row_count > 0) {
				$err [] = "користувач з таким логіном вже існує";
			}
			// якщо помилок нема, створюємо в БД нового користувача
			if (count ( $err ) == 0) {
				$f_name   = $_POST ['f_name'];
				$l_name   = $_POST ['l_name'];
				$date     = $_POST ['user_date'];
				$login    = $_POST ['login'];
				$access   = $_POST ['access'];
				// забираємо пробіли та створюємо подвійний хеш
				$password = md5 ( md5 ( trim ( $_POST ['password'] ) ) );
				$query    = $pdo->query ( "INSERT INTO users SET f_name='" . $f_name . "', l_name='" . $l_name . "', user_login='" . $login . "', user_date='" . $date . "',access='" . $access . "', user_password='" . $password . "'" );
				header("Refresh:1;url=".$dom."/settings.php");
				include $_SERVER ['DOCUMENT_ROOT'] . '/header.php';
				echo "<div class='alert alert-primary my-3' role='alert'>Зачекай...</div>";
				echo "<div class='spinner-grow main-color' role='status'><span class='visually-hidden'>Load...</span></div>";
				$_SESSION['message'] = "<div class='alert alert-success my-3' role='alert'>Додано успішно!</div>";
				exit();
			} else {
				foreach ( $err as $error ) {
					header("Refresh:1;url=".$dom."/settings.php");
					include $_SERVER ['DOCUMENT_ROOT'] . '/header.php';
					echo "<div class='alert alert-primary my-3' role='alert'>Зачекай...</div>";
					echo "<div class='spinner-grow main-color' role='status'><span class='visually-hidden'>Load...</span></div>";
					$_SESSION['message'] = "<div class='alert alert-danger my-3' role='alert'>Помилка: $error !</div>";
					exit();
				}
			}
		}
		//видалити юзера
		if (isset($_POST['del_users'])) {
			$del_user = isset($_POST['checkbox']) ? $_POST['checkbox'] : '';
			if ($del_user == '') {
				$_SESSION['message'] = "<div class='alert alert-danger my-3' role='alert'>Нічого не вибрано!</div>";
				header("Refresh:0;url=".$dom."/settings.php");
				exit();
			}
			foreach ($del_user as $id) {
				if ($user_id == $id) {
					$_SESSION['message'] = "<div class='alert alert-danger my-3' role='alert'>Себе видалити не можна!</div>";
					header("Refresh:0;url=".$dom."/settings.php");
					exit();
				}
				$img_query = $pdo->query ("SELECT * FROM `users` WHERE user_id = '$id'");
				$avatars = $img_query->fetchAll();
				foreach ($avatars as $row) {
					$user_avatar = $row['user_avatar'];
				}
				if (file_exists($dir_abs.'karat/avatars/'.$user_avatar) && $user_avatar !='') {
					unlink($dir_abs.'karat/avatars/'.$user_avatar);
				}
				$query = $pdo->query("DELETE FROM `users` WHERE `user_id` = '$id'");
			}
			header("Refresh:1;url=".$dom."/settings.php");
			include $_SERVER ['DOCUMENT_ROOT'] . '/header.php';
			echo "<div class='alert alert-primary my-3' role='alert'>Видаляю...</div>";
			echo "<div class='spinner-grow main-color' role='status'><span class='visually-hidden'>Load...</span></div>";
			$_SESSION['message'] = "<div class='alert alert-success my-3' role='alert'>Видалено!</div>";
			exit();
		}
		//видалити години
		if (isset($_POST['del_time'])) {
			$del_time = isset($_POST['checkbox']) ? $_POST['checkbox'] : '';
			if ($del_time == '') {
				$_SESSION['message'] = "<div class='alert alert-danger my-3' role='alert'>Нічого не вибрано!</div>";
				header("Refresh:0;url=".$dom."/settings.php");
				exit();
			}
			foreach ($del_time as $id) {
				$query = $pdo->query("DELETE FROM `e_time` WHERE `id` = '$id'");
			}
			header("Refresh:1;url=".$dom."/settings.php");
			include $_SERVER ['DOCUMENT_ROOT'] . '/header.php';
			echo "<div class='alert alert-primary my-3' role='alert'>Видаляю...</div>";
			echo "<div class='spinner-grow main-color' role='status'><span class='visually-hidden'>Load...</span></div>";
			$_SESSION['message'] = "<div class='alert alert-success my-3' role='alert'>Видалено!</div>";
			exit();
		}
		//видалити нульові позиції
		if (isset($_POST['del_null_pcs'])) {
			$del_null_pcs = isset($_POST['checkbox']) ? $_POST['checkbox'] : '';
			if ($del_null_pcs == '') {
				$_SESSION['message'] = "<div class='alert alert-danger my-3' role='alert'>Нічого не вибрано!</div>";
				header("Refresh:0;url=".$dom."/settings.php");
				exit();
			}
			foreach ($del_null_pcs as $product_id) {
				$query = $pdo->query("DELETE FROM `e_prod_to_stor` WHERE `product_id` = '$product_id' AND `pcs` = 0");
			}
			header("Refresh:1;url=".$dom."/settings.php");
			include $_SERVER ['DOCUMENT_ROOT'] . '/header.php';
			echo "<div class='alert alert-primary my-3' role='alert'>Видаляю...</div>";
			echo "<div class='spinner-grow main-color' role='status'><span class='visually-hidden'>Load...</span></div>";
			$_SESSION['message'] = "<div class='alert alert-success my-3' role='alert'>Видалено!</div>";
			exit();
		}
		//видалити меню
		if (isset($_POST['del_menu'])) {
			$del_menu = isset($_POST['checkbox']) ? $_POST['checkbox'] : '';
			if ($del_menu == '') {
				$_SESSION['message'] = "<div class='alert alert-danger my-3' role='alert'>Нічого не вибрано!</div>";
				header("Refresh:0;url=".$dom."/settings.php");
				exit();
			}
			foreach ($del_menu as $id) {
				$query = $pdo->query("DELETE FROM `e_menu` WHERE `id` = '$id'");
			}
			header("Refresh:1;url=".$dom."/settings.php");
			include $_SERVER ['DOCUMENT_ROOT'] . '/header.php';
			echo "<div class='alert alert-primary my-3' role='alert'>Видаляю...</div>";
			echo "<div class='spinner-grow main-color' role='status'><span class='visually-hidden'>Load...</span></div>";
			$_SESSION['message'] = "<div class='alert alert-success my-3' role='alert'>Видалено!</div>";
			exit();
		}
	} else {
		echo "<div class='alert alert-danger my-3' role='alert'>Ви не маєте прав доступу!</div>";
		echo "<div class='desc_err'><img class='img_emo' src='$dom/karat/img/emoji-err.png'></div>";
	}
} else {
	header("Refresh:1;url= /");
	include $_SERVER ['DOCUMENT_ROOT'] . '/header.php';
	echo "<div class='alert alert-danger my-3' role='alert'>Помилка сесії!</div>";
	exit();
}
include $_SERVER ['DOCUMENT_ROOT'] . '/footer.php';
?>