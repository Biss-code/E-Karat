<?php
// ver_3.7.1
if (!file_exists( __DIR__ . '/db.php')) {
	require_once __DIR__ . '/installer.php';
	die();
} else {
	require_once __DIR__ . '/db.php';
}
?>
<?php
include $_SERVER ['DOCUMENT_ROOT'] . '/settdata.php';
$title = $system_name;
include $_SERVER ['DOCUMENT_ROOT'] . '/header.php';
include $_SERVER ['DOCUMENT_ROOT'] . '/karat/stock/functions.php';
$all_menu  = get_menu();
// Перевірка куків та юзера
if (isset ($_COOKIE ['id']) and isset ($_COOKIE ['hash'])) {
?>
<?php
if ($user_date == 0000-00-00 || $user_ava == '') {
?>
<script>
	$(document).ready(function() {
		$("#ProfileModal").modal('show');
	});
</script>
<div id="ProfileModal" class="modal fade modal-sm" tabindex="-1">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Профіль не повний</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body">
				<div class="bg-danger bg-opacity-25 p-3">
					<center>
						<p class="string drop p-2">
							<b>Редагувати профіль ?</b>
						</p>
						<button type="button" class="btn main-color btn-sm">
							<a href="<?php  echo $dom; ?>/karat/menu/e_profile.php?id=<?php  echo $user_id; ?>">
								OK
							</a>
						</button>
					</center>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
} ?>

<div class="card text-center <?php  echo $bg_time; ?>">
	<div class="info_block">
		<?php
		if ($access == "super_admin" || $access == "admin") { ?>
		<button type="button" class="btn btn-sm btn-secondary position-relative">
			<a href="/karat/menu/e_move.php">
				<i class="bi bi-bank"></i>
				<span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
				<?php
				$i = 0;
				$tuday = $cur_time;
				$t_one = strtotime('-1 day 00:00:00');
				$t_two = strtotime('-2 day 00:00:00');
				$min_one_d = date('Y-m-d',$t_one);
				$min_two_d = date('Y-m-d',$t_two);
				$move = $pdo->query("SELECT date_op FROM `e_prod_to_move`")->fetchAll();
				foreach ($move as $row) {
					$date_op = $row['date_op'];
					if (($date_op == $tuday) or ($date_op == $min_one_d) or ($date_op == $min_two_d)) {
						$i++;
					}
				}
				echo $i;
				?>
				</span>
			</a>
		</button>
		<?php
	} ?>
		<button type="button" class="btn btn-sm btn-secondary position-relative">
			<a href="karat/menu/e_post.php">
				<i class="bi bi-book-half"></i>
				<span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
				<?php
				$i = 0;
				$tuday = $cur_time;
				$msg = $pdo->query("SELECT id FROM `e_post` WHERE date = '$tuday'")->fetchAll();
				foreach ($msg as $row) {
					$i++;
				}
				echo $i;
				?>
				</span>
			</a>
		</button>
	</div>
	<?php
	$interval = 2;
	$tuday = date('Y');
	$query = $pdo->query("SELECT * FROM `users`
	WHERE DATE_FORMAT(`user_date`, '%m%d') >= DATE_FORMAT(NOW(), '%m%d')
	AND DATE_FORMAT(`user_date`, '%m%d') <= DATE_FORMAT(DATE_ADD(NOW(),
	INTERVAL '$interval' DAY),'%m%d')
	ORDER BY DATE_FORMAT(`user_date`, '%m%d') ASC");
	$users = $query->fetchAll(PDO::FETCH_ASSOC);
	if ($users) {
		foreach ($users as $row) {
			$name = $row['f_name'];
			$fami = $row['l_name'];
			$birthday = $row['user_date'];
			$date = explode("-", $birthday);
			$year = $date[0];
			$month = $date[1];
			$day = $date[2];
			$age = $tuday - $year;
			echo '<div class="birthday card-img-top">
			<center><b>'.$day.' - '.$month.'<br> Happy Birthday! <br>'.$name.' '.$fami.'<br>
			<span class="badge text-bg-danger">З '.$age.' - річчям</span>
			</b></center></div>';
		}
	} else {
		echo '<img class="card-img-top" src="'.$dom.'/karat/img/karat_back.jpg" alt='.$system_name.'>

		';
	}
	?>
	<div class="card-body">
		<?php
		if ($user_ava != '') { ?>
		<div class="mb-3">
			<img class="prof-pic" src="<?php  echo $dom.'/karat/avatars/'.$user_ava; ?>?<?php   echo time(); ?>" alt="Profile">
		</div>
		<?php
	}
	if ($user_ava == '') { ?>
		<div class="mb-3">
			<img class="prof-pic" src="<?php  echo $dom.'/karat/avatars/default_ava.png'; ?>" alt="Profile">
		</div>
		<?php
	} ?>
		<h1 class="card-title"><?php  echo $system_name; ?></h1>
		<p class="card-text">
			<div class='hi_user'>
				<?php
				if ($userdata) {
					foreach ($userdata as $row) {
						$l_name = $row['l_name'];
						$access = $row['access'];
					}
					if ($l_name != '') {
				?>
				<b>Вітаю, <?php  echo $l_name; ?> <?php  echo $f_name; ?></b>
				<span class="badge text-bg-primary" data-bs-html='true' data-bs-toggle="tooltip" data-bs-title="<span>
				Доступ: <?php  echo $access; ?><br /> Тариф: <?php  echo $stavka_grn; ?> грн. <br /> Ліміт: <?php  echo $limit_watch; ?> год.
				</span>">
				і
				</span>
				<a href="<?php  echo $dom; ?>/karat/menu/e_profile.php?id=<?php  echo $user_id; ?>">
					<span class="badge rounded-pill text-bg-dark"><i class="bi bi-gear-fill"></i></span>
				</a>
				<?php
			}
		}
				?>
			</div>
		</p>
		<div class="row justify-content-center px-4">
			<?php
			$query     = $pdo->query("SELECT * FROM `e_time`");
			$add_dnone = "";
			foreach ($query as $row) {
				$datafiks = $row['date'];
				$format_date = date("d.m.y", strtotime($datafiks));
				$namefiks = $row['name'];
				$timefiks = $row['time'];
				if (($user == $namefiks) && ($datafiks == $max_time && $timefiks > 0)) {
					$add_dnone = " d-none";
			?>
			<div class="d-grid gap-3">
				<a class="btn btn-success mb-3" href="<?php  echo $dom; ?>/karat/menu/e_check.php" role="button">Дата:
					<span class="badge rounded-pill text-bg-danger"><?php  echo $format_date; ?></span> Годин:
					<span class="badge rounded-pill text-bg-danger"><?php  echo $timefiks; ?></span>
				</a>
			</div>
			<?php
		}
	}
			?>
			<div class="d-grid gap-3">
				<?php
				foreach ($all_menu as $row) {
					$id     = $row ['id'];
					$menu_name = $row ['menu_name'];
					$menu_alias = $row ['menu_alias'];
					$menu_file  = $row ['menu_file'];
					$menu_icon  = $row ['menu_icon'];
				?>
				<a class="btn main-color menu<?php
				if ($menu_file == 'e_check.php') {
					echo $add_dnone;
				} ?>" href="<?php  echo $dom; ?>/karat/menu/<?php echo $menu_file; ?>" role="button">
					<?php
					if ($menu_icon != '') { ?>
					<i class="<?php echo $menu_icon; ?> float-start"></i>
					<?php
				} ?><?php echo $menu_name; ?>
				</a>
				<?php
			} ?>
			</div>
		</div>
	</div>
</div>
<div class='text-center my-3'>
	<a class="btn main-color" href="<?php echo $dom.'/karat/menu/e_logout.php'; ?>" role="button">
		<i class="bi bi-box-arrow-in-left"></i> Вийти</a>
</div>
<?php
} else {
	echo "<div class='alert alert-danger my-3' role='alert'>Ви не авторизовані!</div>";
?>
<div class="ramka_full my-3 <?php  echo $bg_time; ?>">
	<div class="form p-4">
		<div class="form_home">
			<div class="row justify-content-center">
				<div class="d-grid gap-3">
					<button class="btn main-color" data-bs-toggle="modal" data-bs-target="#loginModal">
						<i class="bi bi-box-arrow-in-right float-start"></i> ВХІД
					</button>
					<a class="btn main-color" href="<?php echo $dom.'/karat/menu/e_register.php'; ?>" role="button">
						<i class="bi bi-person-add float-start"></i> РЕЄСТРАЦІЯ</a>
					<a class="btn main-color" href="<?php  echo $dom; ?>/karat/menu/e_search.php" role="button">
						<i class="bi bi-search float-start"></i> ПОШУК</a>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
}
include $_SERVER['DOCUMENT_ROOT'].'/g_ads.php';
include $_SERVER ['DOCUMENT_ROOT'] . '/footer.php';
?>