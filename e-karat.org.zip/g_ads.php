<?php if ($gads == '1'){ ?>
<div class="gads" style="bottom: 0px;">
	<?php echo $text_gads; ?>
</div>
<?php } ?>
<?php // include $_SERVER['DOCUMENT_ROOT'].'/g_ads.php'; ?>