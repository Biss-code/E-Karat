<?php
// ver_3.7.1
if ( isset($_SERVER['HTTPS'] ) ) {
	$protocol = 'https://';
	} else {
	$protocol = 'http://';	
	}
session_start();
// Функция для генерации случайной строки
function generateCode($length = 6)
{
	$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHI JKLMNOPRQSTUVWXYZ0123456789";
	$code  = "";
	$clen  = strlen ( $chars ) - 1;
	while ( strlen ( $code ) < $length ) {
		$code .= $chars [mt_rand ( 0, $clen )];
	}
	return $code;
}
require_once $_SERVER['DOCUMENT_ROOT'] . '/db.php';
//Перевірка куків та юзера
if (isset ($_COOKIE ['id']) and isset ($_COOKIE ['hash'])) {
	$query    = $pdo->query("SELECT *,INET_NTOA(user_ip) AS user_ip FROM users WHERE user_id = '".intval($_COOKIE ['id'])."' LIMIT 1");
	$userdata = $query->fetchAll(PDO::FETCH_ASSOC);
	foreach ($userdata as $row) {
		$user_hash = $row['user_hash'];
		$user_id   = $row['user_id'];
		$user_ip   = $row['user_ip'];
		$user      = $row['user_login'];
		$access    = $row['access'];
		$f_name    = $row['f_name'];
		$l_name    = $row['l_name'];
		$user_date = $row['user_date'];
		$user_ava  = $row['user_avatar'];
	}
	if (($user_hash !== $_COOKIE ['hash']) or ((int) $user_id !== (int) $_COOKIE ['id'])
	or (($user_ip !== $_SERVER ['REMOTE_ADDR'])  and ($user_ip !== "0"))) {
		setcookie("id", "", time() - 3600*24*30*12, "/"); //мінус 360 діб
		setcookie("hash", "", time() - 3600*24*30*12, "/"); //мінус 360 діб httponly !!!
		$_SESSION['message'] = "<div class='alert alert-danger my-3' role='alert'>Помилка сесії!</div>";
		header("Refresh:1;url='/'");
	}
}
$query = $pdo->query("SELECT * FROM `settings`");
foreach ($query as $row) {
	$system_name = $row['system_name'];
	$system_logo = $row['system_logo'];
	$limit_watch = $row['limit_watch'];
	$stavka_grn  = $row['stavka_grn'];
	$stock_default  = $row['stock_default'];
	$bg_color    = $row['bg_color'];
	$time_pm     = $row['time_pm'];
	$time_am     = $row['time_am'];
	$gads        = $row['gads'];
	$text_gads   = $row['text_gads'];
	$ver         = $row['ver'];
	$main_color  = $row['main_color'];
}
$dom     = $protocol.$_SERVER['SERVER_NAME'].'';
$dir_abs = $_SERVER['DOCUMENT_ROOT'].'/';
date_default_timezone_set('Europe/Kiev');
$backup        = date("d-m-y");
$today         = date("Y-m-d");
$time_nighte   = date('H:i:s');
$cur_time      = date('Y-m-d');
$max_time      = date('Y-m-d');
$this_mons     = date('m-Y');
$data_start    = date('Y-m-01');
$data_last     = date("Y-m-t"); //останнє число місяця 2023-08-31
//режим ночі
$bg_class = '';
if (($bg_color == '1' and $time_nighte > $time_pm) or ($bg_color == '1' and $time_nighte < $time_am)) {
	$bg_class = 'night';
	$bg_time = 'text-bg-dark';
} else {
	$bg_time = 'text-bg-light';
}
$status = $bg_color ? 'checked' : '';
$ga_status = $gads ? 'checked' : '';
?>