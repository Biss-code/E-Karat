<?php 
if ( isset($_SERVER['HTTPS'] ) ) {
	$protocol = 'https://';
	} else {
	$protocol = 'http://';	
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Система інвентаризації</title>
	<meta name="viewport" content="width=device-width, user-scalable=no">
	<link href="<?php echo $protocol; ?><?php echo $_SERVER['SERVER_NAME']; ?>/karat/css/bootstrap.min.css" rel="stylesheet">
</head>
<style>
.bg {
	background-repeat: no-repeat;
	background-size: cover;
	height: 100vh;
	background-image: url("<?php echo $protocol; ?><?php echo $_SERVER['SERVER_NAME']; ?>/karat/img/karpaty.jpg");
}
</style>
<body>

<div class="bg">
<div class="container">
  <div class="row justify-content-md-center">
  <div class="card text-center mt-5 p-0"  style="width: 18rem;">
	  <img src="<?php echo $protocol; ?><?php echo $_SERVER['SERVER_NAME']; ?>/karat/img/karat_back.jpg" class="card-img-top" alt="Система інвентаризації">
  <div class="card-body">
    <h5 class="card-title">Система інвентаризації</h5>
    <p class="card-text">Усі поля обов'язкові для заповнення!</p>
  </div>
	  <form class="px-3" method="post">
	    <label class="form-label">Хост зазвичай *localhost*</label>
        <input type="text" name="host" required class="form-control" placeholder="localhost">
        <label class="form-label">Ім'я користувача бази данних</label>
        <input type="text" name="username" required class="form-control" placeholder="username">
	    <label class="form-label">Пароль бази данних</label>
	    <input type="text" name="password" class="form-control" placeholder="****">
	    <label class="form-label">Ім'я бази данних</label>
	    <input type="text" name="db_name" required class="form-control" placeholder="db_name">
	    <input class="btn btn-success m-3" type="submit" name="submit" value="OK">
	  </form>
	<?php 
	if (!file_exists( __DIR__ . '/db.php')) {
	if (isset ($_POST['submit'])){
	$con = mysqli_connect($_POST['host'],$_POST['username'],$_POST['password']);
$db_error = false;
if(!@$con)
{
	$db_error = true;
	echo "На жаль, ці дані невірні.";
}
if(!$db_error and !@mysqli_select_db($con,$_POST['db_name']))
{
	$db_error = true;
	echo "Хост, ім'я користувача та пароль правильні. Але щось не так із даною базою даних.";
}
//Import SQL FIle
$filename = 'backup_db.sql';
// Temporary variable, used to store current query
$templine = '';
// Read in entire file
$lines = file($filename);
// Loop through each line
foreach ($lines as $line)
{
// Skip it if it's a comment
if (substr($line, 0, 2) == '--' || $line == '')
	continue;

// Add this line to the current segment
$templine .= $line;
// If it has a semicolon at the end, it's the end of the query
	if (substr(trim($line), -1, 1) == ';'){
		// Perform the query
		if(!mysqli_query($con, $templine)){echo 'Помилка виконання запиту \'<strong>' . $templine . '\': ' . mysqli_error() . '<br /><br />';}
		// Reset temp variable to empty
		$templine = '';
	}
}
$connect_code="<?php 
\$db_host     = '".$_POST['host']."';
\$db_user     = '".$_POST['username']."'; // Логін БД
\$db_password = '".$_POST['password']."'; // Пароль БД
\$db_base     = '".$_POST['db_name']."'; // Ім'я БД
\$pdo     = new PDO(\"mysql:host=\$db_host;dbname=\$db_base\", \$db_user, \$db_password);
\$pdo ->exec('set names utf8');
?>";
$fp = fopen(__DIR__ . '/db.php','a');
fwrite($fp,$connect_code);
fclose($fp);
header("Location: index.php"); 
	}
}else{
	$is_db = '<div class="alert alert-danger" role="alert">Файл бази данних уже існує!</div>';
	echo $is_db;
} ?>
</div>
</div>
</div>
</div>
</body>
</html>