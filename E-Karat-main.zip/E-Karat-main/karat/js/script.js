//----------------------togle all checkbox-------------------
function toggle(source)
{
	checkboxes = document.getElementsByName('checkbox[]');
	for (var i=0, n=checkboxes.length;i<n;i++) {
		checkboxes[i].checked = source.checked;
	}
}
//---------------show / hide block----------------------------
function showHide(element_id)
{
	//if element with element_id yes
	if (document.getElementById(element_id)) {
		var obj = document.getElementById(element_id);
		if (obj.style.display != "block") {
			obj.style.display = "block"; //show block
		} else
			obj.style.display = "none"; //hide block
	}
	//if element with element_id no, message
	else
		alert("Element with id: " + element_id + " NO!");
}
//-----------------Для вибору годин 1 - 24 -------------------
if (document.querySelector('#select_time')) {
	const select = document.querySelector('#select_time');
	for (let i = ''; i <= 24; i++) {
		const option = document.createElement('option');
		option.textContent = option.value = i;
		select.append(option);
	}
}
//-------------import_category--------------------
$(document).ready(function() {
	$('#import_category_rows').on('submit', function(event) {
		event.preventDefault();
		$.ajax(
		{
			url:"../stock/cat_import.php",
			method:"POST",
			data:new FormData(this),
			contentType:false,
			cache:false,
			processData:false,
			beforeSend:function() {
				$('#import').attr('disabled', 'disabled');
				$('#import').val('Імпортую...');
			},
			success:function(data) {
				$('#message').html(data);
				$('#import_category_rows')[0].reset();
				$('#import').attr('disabled', false);
				$('#import').val('Імпорт');
			}
		})
	});
});
//--------------import_products---------------
$(document).ready(function() {
	$('#import_products').on('submit', function(event) {
		event.preventDefault();
		$.ajax(
		{
			url:"../stock/prod_import.php",
			method:"POST",
			data:new FormData(this),
			contentType:false,
			cache:false,
			processData:false,
			beforeSend:function() {
				$('#import').attr('disabled', 'disabled');
				$('#import').val('Імпортую...');
			},
			success:function(data) {
				$('#message').html(data);
				$('#import_products')[0].reset();
				$('#import').attr('disabled', false);
				$('#import').val('Імпорт');
			}
		})
	});
});
//-------------import_store--------------------
$(document).ready(function() {
	$('#import_store_rows').on('submit', function(event) {
		event.preventDefault();
		$.ajax(
		{
			url:"../stock/stor_import.php",
			method:"POST",
			data:new FormData(this),
			contentType:false,
			cache:false,
			processData:false,
			beforeSend:function() {
				$('#import').attr('disabled', 'disabled');
				$('#import').val('Імпортую...');
			},
			success:function(data) {
				$('#message').html(data);
				$('#import_store_rows')[0].reset();
				$('#import').attr('disabled', false);
				$('#import').val('Імпорт');
			}
		})
	});
});
//-------------------hover open menu---------------------------
//$(document).ready(function() {
	//$(".offcanvas-body .navbar-nav li").hover(
	//function() {
	//	$(this).children('ul').hide();
	//	$(this).children('ul').slideDown('fast');
	//},
	//function() {
	//	$(this).children('ul').hide();
	//});
//});
//--------------------------------add class------------------------
$(function() {
	var pgurl = window.location.href.substr(window.location.href.lastIndexOf("/")+1);
	$(".offcanvas-body li").each(function() {
		if ($('a',this).attr("href") == pgurl || $('a', this).attr("href") == '' )
			$(this).addClass("active");
	})
});

//--------------------add initialise tooltips--------------------
const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));
//--------------------Send Search Text to the server----------------
$(document).ready(function () {
	$("#search").keyup(function () {
		let searchText = $(this).val();
		if (searchText != "") {
			$.ajax(
			{
				url: "../stock/search_action.php",
				method: "post",
				data:
				{
					query: searchText,
				},
				success: function (response) {
					$("#show-list").html(response);
				},
			});
		} else {
			$("#show-list").html("");
		}
	});
	// Set searched text in input field on click of search button
	$(document).on("click", "#q_text", function () {
		$("#search").val($(this).text());
		$("#show-list").html("");
	});
});
//-------------------pagination---------------------------
$(document).ready(function () {
	$('#records-limit').change(function () {
		$('.limit').submit();
	})
});
//-------------------e-time-send---------------------------
$(document).ready(function() {
	$('.doba').on('click', 'a[data-option]', function() {
		option = $(this).data('option');
		$('.form-select option[value="' + option + '"]').prop('selected', true);
		$('.time').submit();
	});
});
$(document).ready(function () {
	$('#select_time').change(function () {
		$('.time').submit();
	})
});
//--------------------to top------------------------------
jQuery(document).ready(function() {
	jQuery(window).on("load scroll",function() {
		if (jQuery(this).scrollTop() > 300) {
			jQuery('#toTop').fadeIn(0);
		} else {
			jQuery('#toTop').fadeOut();
		}
	});
	jQuery('#toTop').click(function() {
		jQuery("html, body").animate({scrollTop: 0}, 500);
	});
});
//-------------------------- button back------------------------------------
function goBack()
{
	window.history.back();
}
//------------------------- hide all alert message--------------------------
$(".alert").fadeTo(2000, 100).slideUp(100, function() {
	$(".alert").alert('close');
});

//-------------------------plus minus button-------------------------------
function gtyMinMax(el)
{ /*this function delimits max and min*/
	if (el.value != "") {
		if (parseInt(el.value) < parseInt(el.min)) {
			el.value = el.min;
		}
		if (parseInt(el.value) > parseInt(el.max)) {
			el.value = el.max;
		}
	}
}

function modIn(inId)
{
	if (inId.charAt(0)=='p') {                  /*p for plus*/
		var targetId = inId.match(/\d+/)[0];    /*just keep the number*/
		document.getElementById(targetId).value ++;
		gtyMinMax(document.getElementById(targetId));
	}
	if (inId.charAt(0)=='m') {                  /*m for minus*/
		var targetId = inId.match(/\d+/)[0];
		document.getElementById(targetId).value --;
		gtyMinMax(document.getElementById(targetId));
	}
}
//-------------------------plus minus button printer-------------------------------
var minus_B = document.querySelector(".minus_b")
var add_B = document.querySelector(".add_b");
var quantity_B = document.querySelector(".item-quantity");
const minimum = 1;
if (minus_B != null) {
minus_B.addEventListener("click", function() {
	if (quantity_B.value <= minimum) {
		minus_B.disabled = false;
		return; // return to avoid decrementing
	}
	quantity_B.value--;
})};
if (add_B != null) {
add_B.addEventListener("click", function() {
	if (quantity_B.value > minimum) {
		minus_B.disabled = false;
	}
	quantity_B.value++;
})};
// ------------------------mask for date profile-----------------------------------
$("#date").mask("9999.99.99", {placeholder: "рррр.мм.чч" });
// ------------------------mask for time settings-----------------------------------
$("#time_pm").mask("99:99:99", {placeholder: "20:00:00" });
$("#time_am").mask("99:99:99", {placeholder: "06:00:00" });
// ------------------------show hide password-----------------------------------
function togglePass()
{
	var x = document.getElementById("form_password");
	var l1 = document.getElementById("eye_1");
	var l2 = document.getElementById("eye_2");
	if (x.type === "password") {
		x.type = "text";
		l1.setAttribute('hidden', true);
		l2.removeAttribute('hidden');
	} else {
		x.type = "password";
		l1.removeAttribute('hidden');
		l2.setAttribute('hidden', true);
	}
}
//------------------------------print------------------------------------------------/
function cartAction(action, prod_barcode)
{
	var queryString = "";
	if (action != "") {
		switch (action) {
			case "add":
				queryString = 'action='+action+'&code='+ prod_barcode+'&quantity='+$("#qty_"+prod_barcode).val();
				break;
			case "remove":
				queryString = 'action='+action+'&code='+ prod_barcode;
				break;
			case "empty":
				queryString = 'action='+action;
				break;
		}
	}
	jQuery.ajax({
		url: "../printer/ajax_action.php",
		data:queryString,
		type: "POST",
		success:function(data) {
			$("#cart-item").html(data);
			if (action != "") {
				switch (action) {
					case "add":
						$("#add_"+prod_barcode).hide();
						$("#add_block").hide();
						$("#added_"+prod_barcode).show();
						break;
					case "remove":
						$("#add_"+prod_barcode).show();
						$("#added_"+prod_barcode).hide();
						break;
					case "empty":
						$(".btnAddAction").show();
						$(".btnAdded").hide();
						break;
				}
			}
		},
		error:function () {}
	});
}
//------------------------------end print-----------------------------------------/