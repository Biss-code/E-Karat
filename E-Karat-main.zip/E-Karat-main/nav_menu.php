<?php
// ver_3.7.1
$modal_show = '0';
if (isset ( $_COOKIE ['id'] ) and isset ( $_COOKIE ['hash'] )) {
	$ava_false = '<img class="prof-pic" src="'.$dom.'/karat/avatars/default_ava.png" alt="Profile">';
	$ava_true  = '<img class="prof-pic" src="'.$dom.'/karat/avatars/'.$user_ava.'?'.time().'" alt="Profile">';
}
?>
<nav class="navbar navbar-expand-lg <?php echo $bg_time; ?>">
	<div class="container-fluid">
		<a class="navbar-brand" href="/">
			<div class='logo main-color'>
				<i class="<?php echo $system_logo; ?>"></i>
			</div>
			<div class="site-name float-end py-1 px-2"><b><?php echo $system_name; ?></b></div>
		</a>
		<div class="row">
			<div class="col d-block d-lg-none profile">
				<div class="dropstart">
					<?php
					if (isset ( $_COOKIE ['id'] ) and isset ( $_COOKIE ['hash'] )) { ?>
					<div class="nav_avatar dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
						<?php
						if ($user_ava == FALSE) {
							echo $ava_false;
						}
						if ($user_ava == TRUE) {
							echo $ava_true;
						}
						?>
					</div>
					<ul class="dropdown-menu">
						<li>
						<a class="dropdown-item" href="<?php echo $dom.'/karat/menu/e_profile.php?id='; ?><?php echo $user_id; ?>">
						<i class="bi bi-person-lines-fill"></i> Профіль</a></li>
						<li>
						<a class="dropdown-item" href="<?php echo $dom.'/karat/menu/e_logout.php'; ?>">
						<i class="bi bi-box-arrow-in-left"></i> Вийти</a></li>
					</ul>
					<?php
				} else { ?>
					<!-- Button loginModal -->
					<button class="btn main-color" data-bs-toggle="modal" data-bs-target="#loginModal">
						<i class="bi bi-person-circle"></i>
					</button>
					<?php
					$modal_show = '1';
				} ?>
				</div>
			</div>
			<div class="col">
				<button aria-label="Menu" class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="navbarSupportedContent" aria-expanded="false" aria-controls="offcanvasRight">
					<span class="navbar-toggler-icon">
					</span>
				</button>
			</div>
		</div>
		<div class="offcanvas offcanvas-end <?php echo $bg_time; ?>" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel">
			<div class="offcanvas-header">
				<h5 class="offcanvas-title" id="offcanvasRightLabel">
					Меню
				</h5>
				<button type="button" class="btn btn-secondary btn-sm btn_off_close" data-bs-dismiss="offcanvas" aria-label="Close">
					<i class="bi bi-x-lg"></i>
				</button>
			</div>
			<div class="offcanvas-body">
				<ul class="navbar-nav me-auto mb-2 mb-lg-0">
					<li class="nav-item">
					<a class="nav-link" href="/">
					<i class="bi bi-house-fill"></i> Головна
					</a>
					</li>
					<?php
					if (isset ( $_COOKIE ['id'] ) and isset ( $_COOKIE ['hash'] )) {
						if ($access == "super_admin" || $access == "admin") {
					?>
					<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
					<i class="bi bi-shop"></i> Склад
					</a>
					<ul class="dropdown-menu">
					<li>
					<a class="dropdown-item" href="/karat/menu/e_categories.php">
					<i class="bi bi-folder-fill"></i> Категорії</a></li>
					<li>
					<a class="dropdown-item" href="/karat/menu/e_products.php">
					<i class="bi bi-database-fill"></i> Товари</a></li>
					<li>
					<a class="dropdown-item" href="/karat/menu/e_store.php">
					<i class="bi bi-geo-alt-fill"></i> Комірки</a></li>
					<li>
					<a class="dropdown-item" href="/karat/menu/e_instock.php">
					<i class="bi bi-plus-square"></i> Прихід</a></li>
					<li>
					<a class="dropdown-item" href="/karat/menu/e_outstock.php">
					<i class="bi bi-dash-square"></i> Списання</a></li>
					<?php
					if ($stock_default == 0) { ?>
					<li>
					<a class="dropdown-item" href="/karat/menu/e_restock.php">
					<i class="bi bi-arrow-left-right"></i> Переміщення</a></li>
					<?php
				} ?>
					<li><hr class="dropdown-divider"></li>
					<li>
					<a class="dropdown-item" href="/karat/menu/e_move.php">
					<i class="bi bi-command"></i> Історія товарів</a></li>
					<li>
					<a class="dropdown-item" href="/karat/menu/e_printer.php">
					<i class="bi bi-printer"></i> Друк етикеток</a></li>
					</ul>
					</li>
					<?php
				}
			} ?>
					<?php
					if (isset ( $_COOKIE ['id'] ) and isset ( $_COOKIE ['hash'] )) {
					?>
					<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
					<i class="bi bi-clock-fill"></i> Робота
					</a>
					<ul class="dropdown-menu">
					<?php
					if ($access == "super_admin" || $access == "admin") {
					?>
					<li>
					<a class="dropdown-item" href="/karat/menu/e_zvit.php">
					<i class="bi bi-watch"></i> Звіт +</a></li>
					<li>
					<a class="dropdown-item" href="/karat/menu/e_tabel.php">
					<i class="bi bi-layout-text-sidebar-reverse"></i> Табель</a></li>
					<?php
				} ?>

					<li>
					<a class="dropdown-item" href="/karat/menu/e_shop.php">
					<i class="bi bi-diagram-3"></i> Каталог</a></li>
					<li>
					<a class="dropdown-item" href="/karat/menu/e_post.php">
					<i class="bi bi-pencil-square"></i> Щоденник</a></li>
					<li>
					<a class="dropdown-item" href="/karat/menu/e_bil_pbees.php">
					<i class="bi bi-lightning"></i> Білети ПБЕЕС</a></li>
					<li>
					<a class="dropdown-item" href="/karat/menu/e_bil_ptees.php">
					<i class="bi bi-lightning"></i> Білети ПТЕЕС</a></li>
					<li>
					<a class="dropdown-item" href="/karat/time/elektrobezpeka.pdf">
					<i class="bi bi-lightning"></i> Електробезпека</a></li>
					</ul>
					</li>
					<?php
				} ?>
				</ul>
				<div class="d-flex">
					<?php
					if (isset ( $_COOKIE ['id'] ) and isset ( $_COOKIE ['hash'] )) {
						if ($access == "super_admin" || $access == "admin") { ?>
					<button type="button" class="btn main-color me-1">
						<a href="/settings.php" aria-label="Налаштування">
							<i class="bi bi-shield-lock"></i></a></button>
					<button type="button" class="btn main-color position-relative me-1">
						<a href="/karat/menu/e_alarm.php" aria-label="Тривога">
							<i class="bi bi-bell"></i></a>:
						<?php
						$sql = "SELECT COUNT(*) FROM e_prod_to_stor WHERE pcs <= 1";
						$res = $pdo->query($sql);
						$count = $res->fetchColumn();
						echo $count;
						if ($count) {
							echo '<span class="position-absolute top-0 start-100 translate-middle badge border border-light rounded-circle bg-danger p-1"><span class="visually-hidden">alarm messages</span></span>';
						}
						?>
					</button>
					<?php
				}
			} ?>
					<button type="button" class="btn main-color me-2">
						<a href="/karat/menu/e_search.php" aria-label="Пошук">
							<i class="bi bi-search"></i></a></button>
					<?php
					if (isset ( $_COOKIE ['id'] ) and isset ( $_COOKIE ['hash'] )) {
					?>
					<button type="button" class="btn btn-danger">
						<a href="/karat/menu/e_pos.php" aria-label="Термінал"><b>POS</b></a></button>
					<?php
				} ?>
				</div>
			</div>
		</div>
		<?php
		if ($modal_show == 1) { ?>
		<!-- Modal loginModal -->
		<div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h1 class="modal-title fs-5" id="loginModalLabel">Авторизація</h1>
						<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					</div>
					<div class="modal-body">
						<?php include $_SERVER['DOCUMENT_ROOT']. '/karat/users/mod_login.php'; ?>
					</div>
				</div>
			</div>
		</div>
		<?php
	} ?>
	</div>
</nav>